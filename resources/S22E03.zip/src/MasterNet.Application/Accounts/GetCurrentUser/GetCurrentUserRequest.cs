namespace MasterNet.Application.Accounts.GetCurrentUser;

public class GetCurrentUserRequest
{

    public string? Email {get;set;}

}