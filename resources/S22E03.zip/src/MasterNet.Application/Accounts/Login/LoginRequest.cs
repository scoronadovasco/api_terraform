namespace MasterNet.Application.Accounts.Login;

public class LoginRequest
{
    public string? Email { get; set; }
    public string? Password { get; set; }
}