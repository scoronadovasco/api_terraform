﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace MasterNet.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class MigracionSeguridad : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "cursos",
                keyColumn: "Id",
                keyValue: new Guid("0c76b2b9-0fce-41c4-be0e-485479a5f435"));

            migrationBuilder.DeleteData(
                table: "cursos",
                keyColumn: "Id",
                keyValue: new Guid("39ba18cb-b1a0-4db4-96ae-95c00f2f318a"));

            migrationBuilder.DeleteData(
                table: "cursos",
                keyColumn: "Id",
                keyValue: new Guid("631e0990-c716-490a-b8a9-bea3a12afd0d"));

            migrationBuilder.DeleteData(
                table: "cursos",
                keyColumn: "Id",
                keyValue: new Guid("677560d4-c964-419e-863f-8bec382c2cb0"));

            migrationBuilder.DeleteData(
                table: "cursos",
                keyColumn: "Id",
                keyValue: new Guid("83fb0adf-cfe4-480b-a2b3-8fb0c5478013"));

            migrationBuilder.DeleteData(
                table: "cursos",
                keyColumn: "Id",
                keyValue: new Guid("a7e7cc3c-849d-4e42-9fb9-441c2ae90746"));

            migrationBuilder.DeleteData(
                table: "cursos",
                keyColumn: "Id",
                keyValue: new Guid("bf203e56-d1d5-4164-9ad9-30ccf8ea4d52"));

            migrationBuilder.DeleteData(
                table: "cursos",
                keyColumn: "Id",
                keyValue: new Guid("f4c0d9d1-9bee-4c70-8176-66a477a79279"));

            migrationBuilder.DeleteData(
                table: "cursos",
                keyColumn: "Id",
                keyValue: new Guid("fe6c9159-23fd-4f04-8d76-29bd4d66a425"));

            migrationBuilder.DeleteData(
                table: "instructores",
                keyColumn: "Id",
                keyValue: new Guid("1fe11b31-1a96-476b-96d5-707670077e21"));

            migrationBuilder.DeleteData(
                table: "instructores",
                keyColumn: "Id",
                keyValue: new Guid("42167fb0-b841-45da-a465-67e0bf8d9de8"));

            migrationBuilder.DeleteData(
                table: "instructores",
                keyColumn: "Id",
                keyValue: new Guid("487e4ed5-6722-4182-a0c5-00ac47331f5e"));

            migrationBuilder.DeleteData(
                table: "instructores",
                keyColumn: "Id",
                keyValue: new Guid("66ab35e8-f400-45ef-a4f3-3e82e4ccaa8d"));

            migrationBuilder.DeleteData(
                table: "instructores",
                keyColumn: "Id",
                keyValue: new Guid("7bfdbc74-42fd-4494-a4b8-312607a4951f"));

            migrationBuilder.DeleteData(
                table: "instructores",
                keyColumn: "Id",
                keyValue: new Guid("8b438f46-2a24-4d60-ac1f-174261a0c6b9"));

            migrationBuilder.DeleteData(
                table: "instructores",
                keyColumn: "Id",
                keyValue: new Guid("9750a3ad-d95e-4b9e-88bf-a2db4c531d49"));

            migrationBuilder.DeleteData(
                table: "instructores",
                keyColumn: "Id",
                keyValue: new Guid("e0b2dc33-cf27-486e-a746-fcab42b1a965"));

            migrationBuilder.DeleteData(
                table: "instructores",
                keyColumn: "Id",
                keyValue: new Guid("e2cd2d4a-e60b-4cc2-a984-ba25738ba436"));

            migrationBuilder.DeleteData(
                table: "instructores",
                keyColumn: "Id",
                keyValue: new Guid("eb6341cb-d8ff-4e63-9e16-235c2386489e"));

            migrationBuilder.DeleteData(
                table: "precios",
                keyColumn: "Id",
                keyValue: new Guid("8aed76b7-48b3-42b2-8fdc-181b9a551638"));

            migrationBuilder.CreateTable(
                name: "AspNetRoles",
                columns: table => new
                {
                    Id = table.Column<string>(type: "TEXT", nullable: false),
                    Name = table.Column<string>(type: "TEXT", maxLength: 256, nullable: true),
                    NormalizedName = table.Column<string>(type: "TEXT", maxLength: 256, nullable: true),
                    ConcurrencyStamp = table.Column<string>(type: "TEXT", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetRoles", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUsers",
                columns: table => new
                {
                    Id = table.Column<string>(type: "TEXT", nullable: false),
                    NombreCompleto = table.Column<string>(type: "TEXT", nullable: true),
                    Carrera = table.Column<string>(type: "TEXT", nullable: true),
                    UserName = table.Column<string>(type: "TEXT", maxLength: 256, nullable: true),
                    NormalizedUserName = table.Column<string>(type: "TEXT", maxLength: 256, nullable: true),
                    Email = table.Column<string>(type: "TEXT", maxLength: 256, nullable: true),
                    NormalizedEmail = table.Column<string>(type: "TEXT", maxLength: 256, nullable: true),
                    EmailConfirmed = table.Column<bool>(type: "INTEGER", nullable: false),
                    PasswordHash = table.Column<string>(type: "TEXT", nullable: true),
                    SecurityStamp = table.Column<string>(type: "TEXT", nullable: true),
                    ConcurrencyStamp = table.Column<string>(type: "TEXT", nullable: true),
                    PhoneNumber = table.Column<string>(type: "TEXT", nullable: true),
                    PhoneNumberConfirmed = table.Column<bool>(type: "INTEGER", nullable: false),
                    TwoFactorEnabled = table.Column<bool>(type: "INTEGER", nullable: false),
                    LockoutEnd = table.Column<DateTimeOffset>(type: "TEXT", nullable: true),
                    LockoutEnabled = table.Column<bool>(type: "INTEGER", nullable: false),
                    AccessFailedCount = table.Column<int>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUsers", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "AspNetRoleClaims",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    RoleId = table.Column<string>(type: "TEXT", nullable: false),
                    ClaimType = table.Column<string>(type: "TEXT", nullable: true),
                    ClaimValue = table.Column<string>(type: "TEXT", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetRoleClaims", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AspNetRoleClaims_AspNetRoles_RoleId",
                        column: x => x.RoleId,
                        principalTable: "AspNetRoles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserClaims",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    UserId = table.Column<string>(type: "TEXT", nullable: false),
                    ClaimType = table.Column<string>(type: "TEXT", nullable: true),
                    ClaimValue = table.Column<string>(type: "TEXT", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserClaims", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AspNetUserClaims_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserLogins",
                columns: table => new
                {
                    LoginProvider = table.Column<string>(type: "TEXT", nullable: false),
                    ProviderKey = table.Column<string>(type: "TEXT", nullable: false),
                    ProviderDisplayName = table.Column<string>(type: "TEXT", nullable: true),
                    UserId = table.Column<string>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserLogins", x => new { x.LoginProvider, x.ProviderKey });
                    table.ForeignKey(
                        name: "FK_AspNetUserLogins_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserRoles",
                columns: table => new
                {
                    UserId = table.Column<string>(type: "TEXT", nullable: false),
                    RoleId = table.Column<string>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserRoles", x => new { x.UserId, x.RoleId });
                    table.ForeignKey(
                        name: "FK_AspNetUserRoles_AspNetRoles_RoleId",
                        column: x => x.RoleId,
                        principalTable: "AspNetRoles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_AspNetUserRoles_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserTokens",
                columns: table => new
                {
                    UserId = table.Column<string>(type: "TEXT", nullable: false),
                    LoginProvider = table.Column<string>(type: "TEXT", nullable: false),
                    Name = table.Column<string>(type: "TEXT", nullable: false),
                    Value = table.Column<string>(type: "TEXT", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserTokens", x => new { x.UserId, x.LoginProvider, x.Name });
                    table.ForeignKey(
                        name: "FK_AspNetUserTokens_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[,]
                {
                    { "a1c1474f-808e-49f5-94db-073c9ba3cb28", null, "CLIENT", "CLIENT" },
                    { "d9eb89e7-3d58-432b-b9d1-6be0d76d48ec", null, "ADMIN", "ADMIN" }
                });

            migrationBuilder.InsertData(
                table: "cursos",
                columns: new[] { "Id", "Descripcion", "FechaPublicacion", "Titulo" },
                values: new object[,]
                {
                    { new Guid("06584d98-963f-4aa1-aa5c-3d69d54aab55"), "The Nagasaki Lander is the trademarked name of several series of Nagasaki sport bikes, that started with the 1984 ABC800J", new DateTime(2024, 4, 9, 19, 29, 11, 627, DateTimeKind.Utc).AddTicks(5815), "Handmade Steel Car" },
                    { new Guid("1b3af4f2-83d0-41fb-8825-3bbe110e8f30"), "The slim & simple Maple Gaming Keyboard from Dev Byte comes with a sleek body and 7- Color RGB LED Back-lighting for smart functionality", new DateTime(2024, 4, 9, 19, 29, 11, 627, DateTimeKind.Utc).AddTicks(5869), "Fantastic Metal Computer" },
                    { new Guid("21e355c2-bf6e-49d2-b211-b7af25731f52"), "The Football Is Good For Training And Recreational Purposes", new DateTime(2024, 4, 9, 19, 29, 11, 627, DateTimeKind.Utc).AddTicks(5940), "Handcrafted Rubber Chair" },
                    { new Guid("47aa6696-a442-45f7-b953-c63ab5c8660a"), "New ABC 13 9370, 13.3, 5th Gen CoreA5-8250U, 8GB RAM, 256GB SSD, power UHD Graphics, OS 10 Home, OS Office A & J 2016", new DateTime(2024, 4, 9, 19, 29, 11, 627, DateTimeKind.Utc).AddTicks(5831), "Gorgeous Granite Bike" },
                    { new Guid("6f4f1ac8-0fe7-4d26-9491-fa079468eaf6"), "New ABC 13 9370, 13.3, 5th Gen CoreA5-8250U, 8GB RAM, 256GB SSD, power UHD Graphics, OS 10 Home, OS Office A & J 2016", new DateTime(2024, 4, 9, 19, 29, 11, 627, DateTimeKind.Utc).AddTicks(5918), "Tasty Concrete Mouse" },
                    { new Guid("79ef0bab-e865-4e32-bbad-5faf9c569094"), "The Nagasaki Lander is the trademarked name of several series of Nagasaki sport bikes, that started with the 1984 ABC800J", new DateTime(2024, 4, 9, 19, 29, 11, 627, DateTimeKind.Utc).AddTicks(5908), "Tasty Wooden Table" },
                    { new Guid("aa3582ad-67d7-44c9-9fdb-05efc1efc951"), "Ergonomic executive chair upholstered in bonded black leather and PVC padded seat and back for all-day comfort and support", new DateTime(2024, 4, 9, 19, 29, 11, 627, DateTimeKind.Utc).AddTicks(5930), "Practical Steel Car" },
                    { new Guid("c2bd8980-c64b-4b13-b703-b2511b977916"), "Andy shoes are designed to keeping in mind durability as well as trends, the most stylish range of shoes & sandals", new DateTime(2024, 4, 9, 19, 29, 11, 627, DateTimeKind.Utc).AddTicks(5782), "Refined Fresh Pants" },
                    { new Guid("e7b28ae0-fe85-4987-9ed7-493b9e12b084"), "The Nagasaki Lander is the trademarked name of several series of Nagasaki sport bikes, that started with the 1984 ABC800J", new DateTime(2024, 4, 9, 19, 29, 11, 627, DateTimeKind.Utc).AddTicks(5842), "Refined Fresh Bacon" }
                });

            migrationBuilder.InsertData(
                table: "instructores",
                columns: new[] { "Id", "Apellidos", "Grado", "Nombre" },
                values: new object[,]
                {
                    { new Guid("0bd8b1dc-32ab-4951-8196-d704f2b15bc9"), "McClure", "Chief Tactics Manager", "Okey" },
                    { new Guid("29c86c61-0114-4625-992a-4c78b3fa8e57"), "Buckridge", "Direct Configuration Technician", "Geovany" },
                    { new Guid("4964f1de-5f79-42f3-baaf-8179580d9e0a"), "Kovacek", "Internal Solutions Strategist", "Mohammad" },
                    { new Guid("74e37bc6-e375-490b-9c52-af4a3409084b"), "Kub", "Chief Identity Engineer", "Garrick" },
                    { new Guid("7ce9a89f-09a2-4ba8-835b-4dc65a111a81"), "Collins", "Corporate Quality Strategist", "Jaden" },
                    { new Guid("7dcff93d-4167-48be-a4a3-af5e19dc162a"), "Jacobson", "Senior Applications Director", "Erika" },
                    { new Guid("96292e03-c74a-4783-aa07-a4a319b920c8"), "Kuhn", "Lead Data Representative", "Telly" },
                    { new Guid("a3ae2a2f-1770-4b13-bd8c-bf1578034fef"), "Gislason", "Dynamic Program Manager", "Aric" },
                    { new Guid("ab7326f7-b2dc-4a85-b2ca-a4489e8f37cf"), "Wehner", "Dynamic Mobility Coordinator", "Mariam" },
                    { new Guid("c949f42a-c016-4236-89cb-9b9f8e973e5b"), "Mohr", "Direct Interactions Supervisor", "Ed" }
                });

            migrationBuilder.InsertData(
                table: "precios",
                columns: new[] { "Id", "Nombre", "PrecioActual", "PrecioPromocion" },
                values: new object[] { new Guid("c521e35c-5bba-4981-a6b0-5109a5b88eee"), "Precio Regular", 10.0m, 8.0m });

            migrationBuilder.InsertData(
                table: "AspNetRoleClaims",
                columns: new[] { "Id", "ClaimType", "ClaimValue", "RoleId" },
                values: new object[,]
                {
                    { 1, "POLICIES", "CURSO_READ", "d9eb89e7-3d58-432b-b9d1-6be0d76d48ec" },
                    { 2, "POLICIES", "CURSO_UPDATE", "d9eb89e7-3d58-432b-b9d1-6be0d76d48ec" },
                    { 3, "POLICIES", "CURSO_WRITE", "d9eb89e7-3d58-432b-b9d1-6be0d76d48ec" },
                    { 4, "POLICIES", "CURSO_DELETE", "d9eb89e7-3d58-432b-b9d1-6be0d76d48ec" },
                    { 5, "POLICIES", "INSTRUCTOR_CREATE", "d9eb89e7-3d58-432b-b9d1-6be0d76d48ec" },
                    { 6, "POLICIES", "INSTRUCTOR_READ", "d9eb89e7-3d58-432b-b9d1-6be0d76d48ec" },
                    { 7, "POLICIES", "INSTRUCTOR_UPDATE", "d9eb89e7-3d58-432b-b9d1-6be0d76d48ec" },
                    { 8, "POLICIES", "COMENTARIO_READ", "d9eb89e7-3d58-432b-b9d1-6be0d76d48ec" },
                    { 9, "POLICIES", "COMENTARIO_DELETE", "d9eb89e7-3d58-432b-b9d1-6be0d76d48ec" },
                    { 10, "POLICIES", "COMENTARIO_CREATE", "d9eb89e7-3d58-432b-b9d1-6be0d76d48ec" },
                    { 11, "POLICIES", "CURSO_READ", "a1c1474f-808e-49f5-94db-073c9ba3cb28" },
                    { 12, "POLICIES", "INSTRUCTOR_READ", "a1c1474f-808e-49f5-94db-073c9ba3cb28" },
                    { 13, "POLICIES", "COMENTARIO_READ", "a1c1474f-808e-49f5-94db-073c9ba3cb28" },
                    { 14, "POLICIES", "COMENTARIO_CREATE", "a1c1474f-808e-49f5-94db-073c9ba3cb28" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_AspNetRoleClaims_RoleId",
                table: "AspNetRoleClaims",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "RoleNameIndex",
                table: "AspNetRoles",
                column: "NormalizedName",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserClaims_UserId",
                table: "AspNetUserClaims",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserLogins_UserId",
                table: "AspNetUserLogins",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserRoles_RoleId",
                table: "AspNetUserRoles",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "EmailIndex",
                table: "AspNetUsers",
                column: "NormalizedEmail");

            migrationBuilder.CreateIndex(
                name: "UserNameIndex",
                table: "AspNetUsers",
                column: "NormalizedUserName",
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AspNetRoleClaims");

            migrationBuilder.DropTable(
                name: "AspNetUserClaims");

            migrationBuilder.DropTable(
                name: "AspNetUserLogins");

            migrationBuilder.DropTable(
                name: "AspNetUserRoles");

            migrationBuilder.DropTable(
                name: "AspNetUserTokens");

            migrationBuilder.DropTable(
                name: "AspNetRoles");

            migrationBuilder.DropTable(
                name: "AspNetUsers");

            migrationBuilder.DeleteData(
                table: "cursos",
                keyColumn: "Id",
                keyValue: new Guid("06584d98-963f-4aa1-aa5c-3d69d54aab55"));

            migrationBuilder.DeleteData(
                table: "cursos",
                keyColumn: "Id",
                keyValue: new Guid("1b3af4f2-83d0-41fb-8825-3bbe110e8f30"));

            migrationBuilder.DeleteData(
                table: "cursos",
                keyColumn: "Id",
                keyValue: new Guid("21e355c2-bf6e-49d2-b211-b7af25731f52"));

            migrationBuilder.DeleteData(
                table: "cursos",
                keyColumn: "Id",
                keyValue: new Guid("47aa6696-a442-45f7-b953-c63ab5c8660a"));

            migrationBuilder.DeleteData(
                table: "cursos",
                keyColumn: "Id",
                keyValue: new Guid("6f4f1ac8-0fe7-4d26-9491-fa079468eaf6"));

            migrationBuilder.DeleteData(
                table: "cursos",
                keyColumn: "Id",
                keyValue: new Guid("79ef0bab-e865-4e32-bbad-5faf9c569094"));

            migrationBuilder.DeleteData(
                table: "cursos",
                keyColumn: "Id",
                keyValue: new Guid("aa3582ad-67d7-44c9-9fdb-05efc1efc951"));

            migrationBuilder.DeleteData(
                table: "cursos",
                keyColumn: "Id",
                keyValue: new Guid("c2bd8980-c64b-4b13-b703-b2511b977916"));

            migrationBuilder.DeleteData(
                table: "cursos",
                keyColumn: "Id",
                keyValue: new Guid("e7b28ae0-fe85-4987-9ed7-493b9e12b084"));

            migrationBuilder.DeleteData(
                table: "instructores",
                keyColumn: "Id",
                keyValue: new Guid("0bd8b1dc-32ab-4951-8196-d704f2b15bc9"));

            migrationBuilder.DeleteData(
                table: "instructores",
                keyColumn: "Id",
                keyValue: new Guid("29c86c61-0114-4625-992a-4c78b3fa8e57"));

            migrationBuilder.DeleteData(
                table: "instructores",
                keyColumn: "Id",
                keyValue: new Guid("4964f1de-5f79-42f3-baaf-8179580d9e0a"));

            migrationBuilder.DeleteData(
                table: "instructores",
                keyColumn: "Id",
                keyValue: new Guid("74e37bc6-e375-490b-9c52-af4a3409084b"));

            migrationBuilder.DeleteData(
                table: "instructores",
                keyColumn: "Id",
                keyValue: new Guid("7ce9a89f-09a2-4ba8-835b-4dc65a111a81"));

            migrationBuilder.DeleteData(
                table: "instructores",
                keyColumn: "Id",
                keyValue: new Guid("7dcff93d-4167-48be-a4a3-af5e19dc162a"));

            migrationBuilder.DeleteData(
                table: "instructores",
                keyColumn: "Id",
                keyValue: new Guid("96292e03-c74a-4783-aa07-a4a319b920c8"));

            migrationBuilder.DeleteData(
                table: "instructores",
                keyColumn: "Id",
                keyValue: new Guid("a3ae2a2f-1770-4b13-bd8c-bf1578034fef"));

            migrationBuilder.DeleteData(
                table: "instructores",
                keyColumn: "Id",
                keyValue: new Guid("ab7326f7-b2dc-4a85-b2ca-a4489e8f37cf"));

            migrationBuilder.DeleteData(
                table: "instructores",
                keyColumn: "Id",
                keyValue: new Guid("c949f42a-c016-4236-89cb-9b9f8e973e5b"));

            migrationBuilder.DeleteData(
                table: "precios",
                keyColumn: "Id",
                keyValue: new Guid("c521e35c-5bba-4981-a6b0-5109a5b88eee"));

            migrationBuilder.InsertData(
                table: "cursos",
                columns: new[] { "Id", "Descripcion", "FechaPublicacion", "Titulo" },
                values: new object[,]
                {
                    { new Guid("0c76b2b9-0fce-41c4-be0e-485479a5f435"), "New ABC 13 9370, 13.3, 5th Gen CoreA5-8250U, 8GB RAM, 256GB SSD, power UHD Graphics, OS 10 Home, OS Office A & J 2016", new DateTime(2024, 4, 9, 11, 39, 31, 235, DateTimeKind.Utc).AddTicks(6536), "Fantastic Fresh Soap" },
                    { new Guid("39ba18cb-b1a0-4db4-96ae-95c00f2f318a"), "The Football Is Good For Training And Recreational Purposes", new DateTime(2024, 4, 9, 11, 39, 31, 235, DateTimeKind.Utc).AddTicks(6647), "Incredible Granite Shoes" },
                    { new Guid("631e0990-c716-490a-b8a9-bea3a12afd0d"), "Carbonite web goalkeeper gloves are ergonomically designed to give easy fit", new DateTime(2024, 4, 9, 11, 39, 31, 235, DateTimeKind.Utc).AddTicks(6672), "Fantastic Granite Towels" },
                    { new Guid("677560d4-c964-419e-863f-8bec382c2cb0"), "Andy shoes are designed to keeping in mind durability as well as trends, the most stylish range of shoes & sandals", new DateTime(2024, 4, 9, 11, 39, 31, 235, DateTimeKind.Utc).AddTicks(6617), "Unbranded Concrete Mouse" },
                    { new Guid("83fb0adf-cfe4-480b-a2b3-8fb0c5478013"), "Boston's most advanced compression wear technology increases muscle oxygenation, stabilizes active muscles", new DateTime(2024, 4, 9, 11, 39, 31, 235, DateTimeKind.Utc).AddTicks(6739), "Licensed Wooden Mouse" },
                    { new Guid("a7e7cc3c-849d-4e42-9fb9-441c2ae90746"), "The Football Is Good For Training And Recreational Purposes", new DateTime(2024, 4, 9, 11, 39, 31, 235, DateTimeKind.Utc).AddTicks(6717), "Licensed Rubber Bike" },
                    { new Guid("bf203e56-d1d5-4164-9ad9-30ccf8ea4d52"), "The beautiful range of Apple Naturalé that has an exciting mix of natural ingredients. With the Goodness of 100% Natural Ingredients", new DateTime(2024, 4, 9, 11, 39, 31, 235, DateTimeKind.Utc).AddTicks(6491), "Sleek Granite Car" },
                    { new Guid("f4c0d9d1-9bee-4c70-8176-66a477a79279"), "Carbonite web goalkeeper gloves are ergonomically designed to give easy fit", new DateTime(2024, 4, 9, 11, 39, 31, 235, DateTimeKind.Utc).AddTicks(6429), "Gorgeous Plastic Bike" },
                    { new Guid("fe6c9159-23fd-4f04-8d76-29bd4d66a425"), "Ergonomic executive chair upholstered in bonded black leather and PVC padded seat and back for all-day comfort and support", new DateTime(2024, 4, 9, 11, 39, 31, 235, DateTimeKind.Utc).AddTicks(6564), "Small Fresh Chair" }
                });

            migrationBuilder.InsertData(
                table: "instructores",
                columns: new[] { "Id", "Apellidos", "Grado", "Nombre" },
                values: new object[,]
                {
                    { new Guid("1fe11b31-1a96-476b-96d5-707670077e21"), "Block", "Corporate Implementation Architect", "Kellie" },
                    { new Guid("42167fb0-b841-45da-a465-67e0bf8d9de8"), "Schmidt", "Customer Interactions Producer", "Oliver" },
                    { new Guid("487e4ed5-6722-4182-a0c5-00ac47331f5e"), "Barton", "Forward Markets Producer", "Richie" },
                    { new Guid("66ab35e8-f400-45ef-a4f3-3e82e4ccaa8d"), "Leuschke", "International Metrics Developer", "Moses" },
                    { new Guid("7bfdbc74-42fd-4494-a4b8-312607a4951f"), "Witting", "International Implementation Analyst", "Angelita" },
                    { new Guid("8b438f46-2a24-4d60-ac1f-174261a0c6b9"), "Kemmer", "Regional Communications Agent", "Ewell" },
                    { new Guid("9750a3ad-d95e-4b9e-88bf-a2db4c531d49"), "Berge", "Dynamic Creative Agent", "Bradly" },
                    { new Guid("e0b2dc33-cf27-486e-a746-fcab42b1a965"), "Leannon", "Future Metrics Agent", "Lisa" },
                    { new Guid("e2cd2d4a-e60b-4cc2-a984-ba25738ba436"), "Wilkinson", "Central Infrastructure Officer", "Janessa" },
                    { new Guid("eb6341cb-d8ff-4e63-9e16-235c2386489e"), "Considine", "Global Infrastructure Orchestrator", "Maryse" }
                });

            migrationBuilder.InsertData(
                table: "precios",
                columns: new[] { "Id", "Nombre", "PrecioActual", "PrecioPromocion" },
                values: new object[] { new Guid("8aed76b7-48b3-42b2-8fdc-181b9a551638"), "Precio Regular", 10.0m, 8.0m });
        }
    }
}
