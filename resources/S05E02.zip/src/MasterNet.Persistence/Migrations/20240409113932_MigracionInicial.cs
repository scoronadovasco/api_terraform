﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace MasterNet.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class MigracionInicial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "cursos",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "TEXT", nullable: false),
                    Titulo = table.Column<string>(type: "TEXT", nullable: true),
                    Descripcion = table.Column<string>(type: "TEXT", nullable: true),
                    FechaPublicacion = table.Column<DateTime>(type: "TEXT", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_cursos", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "instructores",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "TEXT", nullable: false),
                    Apellidos = table.Column<string>(type: "TEXT", nullable: true),
                    Nombre = table.Column<string>(type: "TEXT", nullable: true),
                    Grado = table.Column<string>(type: "TEXT", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_instructores", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "precios",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "TEXT", nullable: false),
                    Nombre = table.Column<string>(type: "VARCHAR", maxLength: 250, nullable: true),
                    PrecioActual = table.Column<decimal>(type: "TEXT", precision: 10, scale: 2, nullable: false),
                    PrecioPromocion = table.Column<decimal>(type: "TEXT", precision: 10, scale: 2, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_precios", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "calificaciones",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "TEXT", nullable: false),
                    Alumno = table.Column<string>(type: "TEXT", nullable: true),
                    Puntaje = table.Column<int>(type: "INTEGER", nullable: false),
                    Comentario = table.Column<string>(type: "TEXT", nullable: true),
                    CursoId = table.Column<Guid>(type: "TEXT", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_calificaciones", x => x.Id);
                    table.ForeignKey(
                        name: "FK_calificaciones_cursos_CursoId",
                        column: x => x.CursoId,
                        principalTable: "cursos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "imagenes",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "TEXT", nullable: false),
                    Url = table.Column<string>(type: "TEXT", nullable: true),
                    CursoId = table.Column<Guid>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_imagenes", x => x.Id);
                    table.ForeignKey(
                        name: "FK_imagenes_cursos_CursoId",
                        column: x => x.CursoId,
                        principalTable: "cursos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "cursos_instructores",
                columns: table => new
                {
                    CursoId = table.Column<Guid>(type: "TEXT", nullable: false),
                    InstructorId = table.Column<Guid>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_cursos_instructores", x => new { x.InstructorId, x.CursoId });
                    table.ForeignKey(
                        name: "FK_cursos_instructores_cursos_CursoId",
                        column: x => x.CursoId,
                        principalTable: "cursos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_cursos_instructores_instructores_InstructorId",
                        column: x => x.InstructorId,
                        principalTable: "instructores",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "cursos_precios",
                columns: table => new
                {
                    CursoId = table.Column<Guid>(type: "TEXT", nullable: false),
                    PrecioId = table.Column<Guid>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_cursos_precios", x => new { x.PrecioId, x.CursoId });
                    table.ForeignKey(
                        name: "FK_cursos_precios_cursos_CursoId",
                        column: x => x.CursoId,
                        principalTable: "cursos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_cursos_precios_precios_PrecioId",
                        column: x => x.PrecioId,
                        principalTable: "precios",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "cursos",
                columns: new[] { "Id", "Descripcion", "FechaPublicacion", "Titulo" },
                values: new object[,]
                {
                    { new Guid("0c76b2b9-0fce-41c4-be0e-485479a5f435"), "New ABC 13 9370, 13.3, 5th Gen CoreA5-8250U, 8GB RAM, 256GB SSD, power UHD Graphics, OS 10 Home, OS Office A & J 2016", new DateTime(2024, 4, 9, 11, 39, 31, 235, DateTimeKind.Utc).AddTicks(6536), "Fantastic Fresh Soap" },
                    { new Guid("39ba18cb-b1a0-4db4-96ae-95c00f2f318a"), "The Football Is Good For Training And Recreational Purposes", new DateTime(2024, 4, 9, 11, 39, 31, 235, DateTimeKind.Utc).AddTicks(6647), "Incredible Granite Shoes" },
                    { new Guid("631e0990-c716-490a-b8a9-bea3a12afd0d"), "Carbonite web goalkeeper gloves are ergonomically designed to give easy fit", new DateTime(2024, 4, 9, 11, 39, 31, 235, DateTimeKind.Utc).AddTicks(6672), "Fantastic Granite Towels" },
                    { new Guid("677560d4-c964-419e-863f-8bec382c2cb0"), "Andy shoes are designed to keeping in mind durability as well as trends, the most stylish range of shoes & sandals", new DateTime(2024, 4, 9, 11, 39, 31, 235, DateTimeKind.Utc).AddTicks(6617), "Unbranded Concrete Mouse" },
                    { new Guid("83fb0adf-cfe4-480b-a2b3-8fb0c5478013"), "Boston's most advanced compression wear technology increases muscle oxygenation, stabilizes active muscles", new DateTime(2024, 4, 9, 11, 39, 31, 235, DateTimeKind.Utc).AddTicks(6739), "Licensed Wooden Mouse" },
                    { new Guid("a7e7cc3c-849d-4e42-9fb9-441c2ae90746"), "The Football Is Good For Training And Recreational Purposes", new DateTime(2024, 4, 9, 11, 39, 31, 235, DateTimeKind.Utc).AddTicks(6717), "Licensed Rubber Bike" },
                    { new Guid("bf203e56-d1d5-4164-9ad9-30ccf8ea4d52"), "The beautiful range of Apple Naturalé that has an exciting mix of natural ingredients. With the Goodness of 100% Natural Ingredients", new DateTime(2024, 4, 9, 11, 39, 31, 235, DateTimeKind.Utc).AddTicks(6491), "Sleek Granite Car" },
                    { new Guid("f4c0d9d1-9bee-4c70-8176-66a477a79279"), "Carbonite web goalkeeper gloves are ergonomically designed to give easy fit", new DateTime(2024, 4, 9, 11, 39, 31, 235, DateTimeKind.Utc).AddTicks(6429), "Gorgeous Plastic Bike" },
                    { new Guid("fe6c9159-23fd-4f04-8d76-29bd4d66a425"), "Ergonomic executive chair upholstered in bonded black leather and PVC padded seat and back for all-day comfort and support", new DateTime(2024, 4, 9, 11, 39, 31, 235, DateTimeKind.Utc).AddTicks(6564), "Small Fresh Chair" }
                });

            migrationBuilder.InsertData(
                table: "instructores",
                columns: new[] { "Id", "Apellidos", "Grado", "Nombre" },
                values: new object[,]
                {
                    { new Guid("1fe11b31-1a96-476b-96d5-707670077e21"), "Block", "Corporate Implementation Architect", "Kellie" },
                    { new Guid("42167fb0-b841-45da-a465-67e0bf8d9de8"), "Schmidt", "Customer Interactions Producer", "Oliver" },
                    { new Guid("487e4ed5-6722-4182-a0c5-00ac47331f5e"), "Barton", "Forward Markets Producer", "Richie" },
                    { new Guid("66ab35e8-f400-45ef-a4f3-3e82e4ccaa8d"), "Leuschke", "International Metrics Developer", "Moses" },
                    { new Guid("7bfdbc74-42fd-4494-a4b8-312607a4951f"), "Witting", "International Implementation Analyst", "Angelita" },
                    { new Guid("8b438f46-2a24-4d60-ac1f-174261a0c6b9"), "Kemmer", "Regional Communications Agent", "Ewell" },
                    { new Guid("9750a3ad-d95e-4b9e-88bf-a2db4c531d49"), "Berge", "Dynamic Creative Agent", "Bradly" },
                    { new Guid("e0b2dc33-cf27-486e-a746-fcab42b1a965"), "Leannon", "Future Metrics Agent", "Lisa" },
                    { new Guid("e2cd2d4a-e60b-4cc2-a984-ba25738ba436"), "Wilkinson", "Central Infrastructure Officer", "Janessa" },
                    { new Guid("eb6341cb-d8ff-4e63-9e16-235c2386489e"), "Considine", "Global Infrastructure Orchestrator", "Maryse" }
                });

            migrationBuilder.InsertData(
                table: "precios",
                columns: new[] { "Id", "Nombre", "PrecioActual", "PrecioPromocion" },
                values: new object[] { new Guid("8aed76b7-48b3-42b2-8fdc-181b9a551638"), "Precio Regular", 10.0m, 8.0m });

            migrationBuilder.CreateIndex(
                name: "IX_calificaciones_CursoId",
                table: "calificaciones",
                column: "CursoId");

            migrationBuilder.CreateIndex(
                name: "IX_cursos_instructores_CursoId",
                table: "cursos_instructores",
                column: "CursoId");

            migrationBuilder.CreateIndex(
                name: "IX_cursos_precios_CursoId",
                table: "cursos_precios",
                column: "CursoId");

            migrationBuilder.CreateIndex(
                name: "IX_imagenes_CursoId",
                table: "imagenes",
                column: "CursoId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "calificaciones");

            migrationBuilder.DropTable(
                name: "cursos_instructores");

            migrationBuilder.DropTable(
                name: "cursos_precios");

            migrationBuilder.DropTable(
                name: "imagenes");

            migrationBuilder.DropTable(
                name: "instructores");

            migrationBuilder.DropTable(
                name: "precios");

            migrationBuilder.DropTable(
                name: "cursos");
        }
    }
}
