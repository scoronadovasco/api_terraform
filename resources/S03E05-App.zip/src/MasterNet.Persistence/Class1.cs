﻿namespace MasterNet.Persistence;

public class Class1
{

}
